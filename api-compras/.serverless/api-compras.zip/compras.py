import boto3
import uuid
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
TABLA_COMPRAS = 'Compras'

def get_table():
    return dynamodb.Table(TABLA_COMPRAS)

def registrar_compra(user_id, tenant_id, data):
    compra_id = str(uuid.uuid4())
    fecha = datetime.utcnow().isoformat()
    compra = {
        'tenantId': tenant_id,
        'userId': user_id,
        'compraId': compra_id,
        'productos': data.get('productos', []),
        'total': data.get('total', 0),
        'fecha': fecha
    }
    table = get_table()
    table.put_item(Item=compra)
    return compra

def listar_compras(user_id, tenant_id):
    table = get_table()
    resp = table.query(
        KeyConditionExpression='tenantId = :t and userId = :u',
        ExpressionAttributeValues={
            ':t': tenant_id,
            ':u': user_id
        },
        IndexName=None  # Usamos la PK compuesta
    )
    return resp.get('Items', []) 