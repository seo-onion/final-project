from jose import jwt, JWTError

SECRET_KEY = 'supersecreto'  # Cambia esto en producción
ALGORITHM = 'HS256'

class UnauthorizedError(Exception):
    pass

def verificar_jwt(token):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        if 'userId' not in payload or 'tenantId' not in payload:
            raise UnauthorizedError('Faltan claims')
        return payload
    except JWTError:
        raise UnauthorizedError('Token inválido') 