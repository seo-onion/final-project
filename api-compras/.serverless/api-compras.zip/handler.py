import json
from compras import registrar_compra, listar_compras
from auth import verificar_jwt, UnauthorizedError

def lambda_handler(event, context):
    try:
        # Autenticación y multi-tenancy
        token = event['headers'].get('Authorization', '').replace('Bearer ', '')
        payload = verificar_jwt(token)
        user_id = payload['userId']
        tenant_id = payload['tenantId']

        if event['httpMethod'] == 'POST' and event['path'] == '/compras':
            body = json.loads(event['body'])
            resp = registrar_compra(user_id, tenant_id, body)
            return {
                'statusCode': 201,
                'body': json.dumps(resp)
            }
        elif event['httpMethod'] == 'GET' and event['path'] == '/compras':
            resp = listar_compras(user_id, tenant_id)
            return {
                'statusCode': 200,
                'body': json.dumps(resp)
            }
        else:
            return {'statusCode': 404, 'body': 'Not found'}
    except UnauthorizedError:
        return {'statusCode': 401, 'body': 'Unauthorized'}
    except Exception as e:
        return {'statusCode': 500, 'body': str(e)} 