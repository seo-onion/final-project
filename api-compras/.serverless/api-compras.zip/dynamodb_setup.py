import boto3

dynamodb = boto3.client('dynamodb')

def crear_tabla():
    try:
        dynamodb.create_table(
            TableName='Compras',
            KeySchema=[
                {'AttributeName': 'tenantId', 'KeyType': 'HASH'},  # Partition key
                {'AttributeName': 'userId', 'KeyType': 'RANGE'}   # Sort key
            ],
            AttributeDefinitions=[
                {'AttributeName': 'tenantId', 'AttributeType': 'S'},
                {'AttributeName': 'userId', 'AttributeType': 'S'}
            ],
            ProvisionedThroughput={'ReadCapacityUnits': 5, 'WriteCapacityUnits': 5}
        )
        print('Tabla Compras creada')
    except dynamodb.exceptions.ResourceInUseException:
        print('La tabla ya existe')

if __name__ == '__main__':
    crear_tabla() 